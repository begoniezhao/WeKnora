---
name: sql-style
description: SQL style guide for writing and reviewing queries. Use when the user writes, formats, or reviews SQL.
---

# SQL style

1. Uppercase keywords, lowercase identifiers in snake_case.
2. One clause per line: `SELECT`, `FROM`, `WHERE`, `GROUP BY`, `ORDER BY`.
3. Always list columns explicitly instead of `SELECT *`.
