---
name: neon-branches
description: Create and manage Neon database branches. Use when the user mentions branching, preview databases, or schema migration testing.
---

# Neon branches

1. List branches with the `neon` MCP server before creating new ones.
2. Name branches after the git branch they back.
