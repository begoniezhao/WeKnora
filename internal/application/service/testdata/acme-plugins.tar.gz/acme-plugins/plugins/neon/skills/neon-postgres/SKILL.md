---
name: neon-postgres
description: Work with Neon Serverless Postgres projects and databases. Use when the user mentions Neon, serverless Postgres, or connection strings.
---

# Neon Postgres

1. Use the `neon` MCP server to list projects before running queries.
2. Look up library documentation with the `context7` MCP server.
3. Prefer pooled connection strings for serverless workloads.
